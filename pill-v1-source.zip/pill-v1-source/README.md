# Pill V1 public source snapshot

Prepared 7 November 2026. Includes custom Solana contracts, SDK, API/indexer source, frontend source and tests. Pangea and Pump protocol implementations belong to their respective providers; this package contains Pill integration code.

## Layout

- `programs/launchpad`: Anchor program, Classic/V1.1 trading, migration, settlement and feature modules.
- `crates/launch-core`: shared curve, fee and vesting logic.
- `sdk/src`: account readers, quotes and instruction builders.
- `services/api`: launch/trade APIs, native Pump and onepill integrations.
- `services/indexer`: chain ingestion, projections, market history and workflows.
- `website`: UI, wallet signing and route integration source.
- `tests`: JavaScript test sources; Rust and Python tests also live beside their modules.

## Local verification

Use Node 22.13 or later and the dependency versions in the manifests. From this directory, install dependencies with `pnpm install`. Pure curve logic can be tested with `cargo test -p launch-core`. The Anchor version is 0.31.1. The website has its own package.json and dependency installation; `npm run build` bundles its client modules.

This is a source review package, not a ready-to-deploy production copy. Environment configuration, chain snapshots, program binaries, runtime databases, mint inventory and private fixture keypairs are excluded. Tests requiring those excluded fixtures cannot run unchanged; supply independently generated test fixtures in an isolated environment. No test private key has been published. The frontend production config/assets are not bundled; supply your own local configuration and assets. The edge origin is replaced with `https://origin.example.invalid`; the build file uses installed esbuild rather than a private workspace fallback.

Do not treat this snapshot as a reproducible verification of the deployed binary, independent security audit or assertion that every experimental module is enabled on the live site. See the repository launch guide for route behavior and its dated readiness notes. No live contracts were changed by this publication.

No broad reuse license is granted by this snapshot. Third-party files retain their existing copyright/license notices.
